## v4.8.8 Changes

* Added support for enchanting, smelting, and poisons for Classic
* Fixed various issues related to Crafting on Classic
* Updated disenchant values for both Classic and Retail
* Added more detailed disenchant/mill/prospecting information to the tooltip
* Fixed various errors seen while using TSM on Classic
* Fixed auction durations for Classic
* Fixed a few errors caused by incorrect translations

[Known Issues](http://support.tradeskillmaster.com/display/KB/TSM4+Currently+Known+Issues)
