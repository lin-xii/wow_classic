## v4.8.14 Changes

* [Classic] Fixed issue with manual scans not recording some items correctly.
* [Classic] Removed guild bank sources from Gathering.

[Known Issues](http://support.tradeskillmaster.com/display/KB/TSM4+Currently+Known+Issues)
